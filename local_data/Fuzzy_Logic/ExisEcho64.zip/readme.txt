Installation
============

Thank you for purchasing ExisEcho.

To install this application simply run the setup included in the installation directory.

IMPORTANT: You Must have an internet connection to install ExisEcho.

This product uses Microsoft Framework 3.5 SP1 which will be installed automatically if you don't have it.

There are some circumstances under which the frame work will not load automatically.  

In those cases simply go to this url and install: http://www.microsoft.com/download/en/details.aspx?id=22

Need help? Please email info@exisone.com

